
export type TaskType = 'daily' | 'todo';

export interface Task {
  id: string;
  text: string;
  type: TaskType;
  completed: boolean;
  lastCompletedAt: string | null; // ISO Date string
  emoji: string;
  duration?: string;
  createdAt: number;
}

export type ViewMode = 'daily' | 'todo';

export interface RoastResponse {
  roast: string;
  color: string;
}

export type Page = 'home' | 'lockin' | 'stats' | 'settings';
