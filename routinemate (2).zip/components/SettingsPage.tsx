import React, { useState } from 'react';
import { Moon, Sun, Monitor, Trash2, AlertTriangle, X } from 'lucide-react';

interface SettingsPageProps {
  isDarkMode: boolean;
  toggleTheme: () => void;
  clearData: () => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({ isDarkMode, toggleTheme, clearData }) => {
  const [showConfirm, setShowConfirm] = useState(false);

  return (
    <div className="p-6 max-w-md mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
       <h2 className="text-3xl font-black font-display uppercase text-mate-ink dark:text-white mb-8">Settings</h2>

       {/* Appearance */}
       <div className="mb-8">
            <h3 className="text-xs font-bold font-mono uppercase text-slate-500 dark:text-slate-400 mb-4">Appearance</h3>
            <div className="bg-white dark:bg-slate-900 border-2 border-mate-ink dark:border-slate-600 rounded-xl overflow-hidden shadow-block dark:shadow-none">
                <button 
                    onClick={toggleTheme}
                    className="w-full p-4 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                >
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-slate-100 dark:bg-slate-800 rounded-lg text-mate-ink dark:text-white">
                            {isDarkMode ? <Moon size={20} /> : <Sun size={20} />}
                        </div>
                        <div className="text-left">
                            <div className="font-bold text-mate-ink dark:text-white">Theme</div>
                            <div className="text-xs text-slate-500">
                                {isDarkMode ? 'Dark Mode Active' : 'Light Mode Active'}
                            </div>
                        </div>
                    </div>
                    <div className={`w-12 h-6 rounded-full p-1 transition-colors ${isDarkMode ? 'bg-mate-blue' : 'bg-slate-300'}`}>
                        <div className={`w-4 h-4 rounded-full bg-white shadow-sm transition-transform ${isDarkMode ? 'translate-x-6' : 'translate-x-0'}`}></div>
                    </div>
                </button>
            </div>
       </div>

       {/* Data Zone */}
       <div>
            <h3 className="text-xs font-bold font-mono uppercase text-red-500 mb-4">Danger Zone</h3>
            <button 
                onClick={() => setShowConfirm(true)}
                className="w-full bg-red-50 dark:bg-red-900/20 border-2 border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 p-4 rounded-xl flex items-center justify-center gap-2 font-bold hover:bg-red-100 dark:hover:bg-red-900/40 transition-colors"
            >
                <Trash2 size={20} />
                Reset All Data
            </button>
       </div>

       {/* Custom Confirmation Modal */}
       {showConfirm && (
           <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-in fade-in duration-200">
               <div className="bg-white dark:bg-mate-dark-card w-full max-w-sm p-6 rounded-2xl border-4 border-red-500 shadow-2xl transform transition-all scale-100">
                   <div className="flex justify-center mb-4 text-red-500">
                       <AlertTriangle size={48} strokeWidth={2.5} />
                   </div>
                   <h3 className="text-2xl font-black font-display text-center uppercase text-mate-ink dark:text-white mb-2">
                       Wipe Everything?
                   </h3>
                   <p className="text-center text-slate-500 dark:text-slate-400 text-sm font-mono mb-6">
                       This will delete all tasks, stats, and your user profile. This cannot be undone.
                   </p>
                   
                   <div className="flex gap-3">
                       <button
                           onClick={() => setShowConfirm(false)}
                           className="flex-1 py-3 font-bold font-display uppercase rounded-lg border-2 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-300 transition-colors"
                       >
                           Cancel
                       </button>
                       <button
                           onClick={() => {
                               clearData();
                               setShowConfirm(false);
                           }}
                           className="flex-1 py-3 font-bold font-display uppercase rounded-lg bg-red-500 text-white shadow-lg hover:bg-red-600 hover:-translate-y-0.5 transition-all flex items-center justify-center gap-2"
                       >
                           <Trash2 size={16} /> Reset
                       </button>
                   </div>
               </div>
           </div>
       )}
    </div>
  );
};
