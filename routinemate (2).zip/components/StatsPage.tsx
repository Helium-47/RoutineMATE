import React from 'react';
import { Task } from '../types';
import { TrendingUp, Award, CalendarCheck, Target, Sparkles, Gem, Shield, Crown, Infinity } from 'lucide-react';

interface StatsPageProps {
  tasks: Task[];
  startDate?: number; // timestamp
  totalAura: number;
  lifetimeCompleted: number;
}

export const StatsPage: React.FC<StatsPageProps> = ({ tasks, startDate, totalAura, lifetimeCompleted }) => {
  const completedTasks = tasks.filter(t => t.completed).length; // Active completed tasks for rate calculation
  const totalTasks = tasks.length;
  // Calculate rate based on current active list to be more relevant to daily/todo view
  const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
  
  // Calculate days since start
  const start = startDate || Date.now();
  const diffTime = Math.abs(Date.now() - start);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
  
  // Determine Tier
  let tier: 'Bronze' | 'Silver' | 'Gold' | 'Diamond' | 'Infinite' = 'Bronze';
  if (totalAura >= 99999) tier = 'Infinite';
  else if (totalAura >= 50000) tier = 'Diamond';
  else if (totalAura >= 17500) tier = 'Gold';
  else if (totalAura >= 7500) tier = 'Silver';
  else tier = 'Bronze';

  return (
    <div className="p-6 max-w-md mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500 pb-28">
      <h2 className="text-3xl font-black font-display uppercase text-mate-ink dark:text-white mb-6 flex items-center gap-2">
        Statistics
      </h2>

      {/* AURA ID CARD */}
      <div className="mb-8 perspective-1000">
        <div className={`
            relative w-full h-56 rounded-2xl p-6 flex flex-col justify-between overflow-hidden transition-all duration-500 transform hover:scale-[1.02] shadow-xl
            ${tier === 'Bronze' ? 'bg-gradient-to-br from-bronze-start to-bronze-end border-4 border-[#78350f]' : ''}
            ${tier === 'Silver' ? 'bg-gradient-to-br from-slate-300 via-slate-100 to-slate-400 border-4 border-slate-400' : ''}
            ${tier === 'Gold' ? 'bg-gradient-to-br from-yellow-500 via-yellow-200 to-yellow-600 border-4 border-yellow-600' : ''}
            ${tier === 'Diamond' ? 'holo-card border-none' : ''}
            ${tier === 'Infinite' ? 'bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 border-4 border-white/50 animate-shine [background-size:200%_200%]' : ''}
        `}>
            {/* Background Texture/Effects */}
            {tier === 'Bronze' && <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>}
            {tier === 'Silver' && <div className="absolute inset-0 opacity-30 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-white to-transparent"></div>}
            {tier === 'Gold' && <div className="absolute inset-0 opacity-40 bg-[radial-gradient(circle,_var(--tw-gradient-stops))] from-yellow-100 via-transparent to-transparent animate-pulse"></div>}
            {tier === 'Diamond' && (
                <>
                    <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 via-purple-500/20 to-pink-500/20 animate-shine [background-size:200%_auto]"></div>
                    <div className="absolute -top-10 -right-10 w-40 h-40 bg-cyan-400/30 rounded-full blur-3xl"></div>
                </>
            )}
            {tier === 'Infinite' && (
                <>
                    <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-20 mix-blend-overlay"></div>
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                    <div className="absolute -bottom-10 -left-10 w-60 h-60 bg-white/20 rounded-full blur-3xl animate-pulse"></div>
                </>
            )}

            {/* Header */}
            <div className="relative z-10 flex justify-between items-start">
                <div className="flex items-center gap-2">
                    <div className="p-2 bg-black/20 rounded-lg backdrop-blur-sm text-white">
                        {tier === 'Bronze' && <Shield size={24} />}
                        {tier === 'Silver' && <Award size={24} />}
                        {tier === 'Gold' && <Crown size={24} />}
                        {tier === 'Diamond' && <Gem size={24} className="text-cyan-100 drop-shadow-[0_0_5px_rgba(0,243,255,0.8)]" />}
                        {tier === 'Infinite' && <Infinity size={24} className="text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.8)]" />}
                    </div>
                    <div>
                        <div className={`font-black uppercase text-xs tracking-widest ${tier === 'Silver' ? 'text-slate-600' : 'text-white/80'}`}>Aura ID</div>
                        <div className={`font-black font-display text-2xl uppercase italic leading-none ${tier === 'Silver' ? 'text-slate-800' : 'text-white'} ${tier === 'Diamond' ? 'text-neon-glow' : ''} ${tier === 'Infinite' ? 'text-transparent bg-clip-text bg-white drop-shadow-[0_2px_2px_rgba(0,0,0,0.3)]' : ''}`}>
                            {tier} Tier
                        </div>
                    </div>
                </div>
                {tier === 'Diamond' && <span className="px-2 py-0.5 bg-cyan-400/20 border border-cyan-400/50 rounded text-[10px] font-bold text-cyan-100 uppercase tracking-widest animate-pulse">Rare</span>}
                {tier === 'Infinite' && <span className="px-2 py-0.5 bg-white/20 border border-white/50 rounded text-[10px] font-bold text-white uppercase tracking-widest shadow-[0_0_10px_rgba(255,255,255,0.4)]">Legend</span>}
            </div>

            {/* Middle / Features */}
            <div className="relative z-10 my-auto">
                {tier === 'Bronze' && <p className="font-mono text-white/90 text-sm font-bold">"Trust the process."</p>}
                {tier === 'Silver' && (
                     <div className="flex items-center gap-2">
                        <span className="bg-white/80 px-2 py-1 rounded text-xs font-bold text-slate-800 uppercase">Certified Valid</span>
                     </div>
                )}
                {tier === 'Gold' && (
                    <div className="flex flex-col">
                        <span className="text-yellow-900 font-black text-lg italic">CEO of Locking In</span>
                        <div className="flex gap-1 mt-1">
                            {[1,2,3].map(i => <StarIcon key={i} className="text-yellow-100" />)}
                        </div>
                    </div>
                )}
                {tier === 'Diamond' && (
                    <div className="space-y-1">
                        <div className="font-black text-2xl text-transparent bg-clip-text bg-gradient-to-r from-cyan-100 to-white drop-shadow-[0_0_2px_rgba(0,0,0,0.5)] italic">
                            MAIN CHARACTER
                        </div>
                        <div className="text-[10px] font-mono text-cyan-200">#NO_CAP #GLITCH_MODE</div>
                    </div>
                )}
                {tier === 'Infinite' && (
                    <div className="space-y-1">
                        <div className="font-black text-3xl text-white drop-shadow-[0_2px_0px_rgba(0,0,0,0.2)] italic tracking-tighter">
                            UNSTOPPABLE
                        </div>
                        <div className="text-[10px] font-mono text-white/90 font-bold bg-white/20 inline-block px-1 rounded">BEYOND GODLIKE</div>
                    </div>
                )}
            </div>

            {/* Footer / Stats */}
            <div className="relative z-10 bg-black/10 backdrop-blur-md rounded-lg p-3 flex justify-between items-center border border-white/10">
                 <div>
                    <div className={`text-[10px] font-bold uppercase ${tier === 'Silver' ? 'text-slate-700' : 'text-white/70'}`}>Total Aura</div>
                    <div className={`text-xl font-black font-mono ${tier === 'Silver' ? 'text-slate-900' : 'text-white'}`}>
                        {totalAura.toLocaleString()}
                    </div>
                 </div>
                 <div className="text-right">
                    <div className={`text-[10px] font-bold uppercase ${tier === 'Silver' ? 'text-slate-700' : 'text-white/70'}`}>Streak</div>
                    <div className={`text-xl font-black font-mono ${tier === 'Silver' ? 'text-slate-900' : 'text-white'}`}>
                        {diffDays}d
                    </div>
                 </div>
            </div>
        </div>
        
        <p className="text-center text-[10px] font-mono uppercase text-slate-400 mt-3">
            Unlock higher tiers by increasing your Aura score.
        </p>
      </div>

      {/* Standard Stats Grid */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <StatCard 
            label="Completion" 
            value={`${completionRate}%`} 
            icon={<Target size={20} />}
            color="bg-mate-blue dark:bg-mate-blue"
        />
        <StatCard 
            label="Tasks Done" 
            value={lifetimeCompleted.toLocaleString()} 
            icon={<CalendarCheck size={20} />}
            color="bg-mate-success dark:bg-mate-success"
        />
      </div>

      {/* Recent History */}
      <div className="bg-white dark:bg-mate-dark-card border-2 border-mate-ink dark:border-white/20 rounded-xl p-4 shadow-sm">
         <h3 className="font-bold font-display uppercase text-sm text-slate-500 dark:text-slate-400 mb-4 border-b pb-2 dark:border-slate-800">Recent Activity</h3>
         <div className="space-y-3">
            {tasks.slice(0, 5).map(task => (
                <div key={task.id} className="flex justify-between items-center text-sm">
                    <span className={`flex items-center gap-2 font-bold ${task.completed ? 'text-mate-ink dark:text-white' : 'text-slate-400'}`}>
                        <span>{task.emoji}</span>
                        <span className={task.completed ? '' : 'line-through decoration-2'}>{task.text}</span>
                    </span>
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${task.completed ? 'bg-green-100 text-green-700 dark:bg-green-900/50 dark:text-green-300' : 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-500'}`}>
                        {task.completed ? 'DONE' : 'PENDING'}
                    </span>
                </div>
            ))}
            {tasks.length === 0 && <p className="text-slate-400 text-xs italic">No activity recorded.</p>}
         </div>
      </div>
    </div>
  );
};

const StatCard = ({ label, value, icon, color }: { label: string, value: string, icon: React.ReactNode, color: string }) => (
    <div className="bg-white dark:bg-mate-dark-card border-2 border-mate-ink dark:border-white/20 rounded-xl p-4 shadow-block-sm dark:shadow-none flex flex-col justify-between h-28 group hover:-translate-y-1 transition-transform">
        <div className={`self-start p-2 rounded-lg text-white ${color} shadow-sm group-hover:scale-110 transition-transform`}>
            {icon}
        </div>
        <div>
            <div className="text-2xl font-black font-display text-mate-ink dark:text-white">{value}</div>
            <div className="text-[10px] font-bold uppercase text-slate-400">{label}</div>
        </div>
    </div>
);

const StarIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor" stroke="none" className={className}>
      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
    </svg>
)