import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RefreshCw, Save } from 'lucide-react';

export const LockInPage: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState<'focus' | 'break'>('focus');
  const [isEditing, setIsEditing] = useState(false);
  
  // Custom durations in minutes
  const [focusDuration, setFocusDuration] = useState(25);
  const [breakDuration, setBreakDuration] = useState(5);
  
  // Input state for editing
  const [inputVal, setInputVal] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  
  const [timeLeft, setTimeLeft] = useState(25 * 60); 

  // Reset timer ONLY when durations change or mode changes. 
  // Removed isActive/isEditing from dependencies so pausing doesn't reset the time.
  useEffect(() => {
    setTimeLeft(mode === 'focus' ? focusDuration * 60 : breakDuration * 60);
  }, [focusDuration, breakDuration, mode]);

  useEffect(() => {
    let interval: number | undefined;

    if (isActive && timeLeft > 0) {
      interval = window.setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsActive(false);
    }

    return () => clearInterval(interval);
  }, [isActive, timeLeft]);

  // Auto-focus input when editing starts
  useEffect(() => {
      if (isEditing && inputRef.current) {
          inputRef.current.focus();
          setInputVal(mode === 'focus' ? focusDuration.toString() : breakDuration.toString());
      }
  }, [isEditing, mode, focusDuration, breakDuration]);

  const toggleTimer = () => {
      if (isEditing) {
          saveEdit();
      }
      setIsActive(!isActive);
  };
  
  const resetTimer = () => {
    setIsActive(false);
    setIsEditing(false);
    setTimeLeft(mode === 'focus' ? focusDuration * 60 : breakDuration * 60);
  };

  const setFocusMode = () => {
    setMode('focus');
    setIsActive(false);
    setIsEditing(false);
    // Note: useEffect will handle the time update because 'mode' changes
  };

  const setBreakMode = () => {
    setMode('break');
    setIsActive(false);
    // Note: useEffect will handle the time update because 'mode' changes
  };

  const saveEdit = () => {
      const val = parseInt(inputVal);
      if (!isNaN(val) && val > 0) {
          if (mode === 'focus') setFocusDuration(val);
          else setBreakDuration(val);
      }
      setIsEditing(false);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const totalTime = mode === 'focus' ? focusDuration * 60 : breakDuration * 60;
  // Progress goes from 0 (start) to 1 (end)
  const progressPercent = totalTime > 0 ? ((totalTime - timeLeft) / totalTime) : 0;
  
  // SVG Config for Break Timer
  const radius = 140;

  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] px-6 animate-page-enter pb-32">
      
      {/* Neon Title */}
      <div className="text-center mb-8 relative group">
        <h2 className="text-4xl md:text-6xl font-black font-display italic uppercase text-mate-ink dark:text-white dark:drop-shadow-[0_0_15px_rgba(255,255,255,0.6)]">
          {mode === 'focus' ? 'Lock In' : 'Touch Grass'}
        </h2>
        <div className={`h-1.5 w-full mt-2 rounded-full shadow-block dark:shadow-[0_0_15px_rgba(0,180,216,0.6)] transition-colors duration-500 ${mode === 'focus' ? 'bg-mate-ink dark:bg-neon-blue' : 'bg-mate-success dark:bg-neon-green'}`}></div>
      </div>

      {/* CREATIVE COUNTDOWN CIRCLE */}
      <div 
        className="relative mb-10 group cursor-pointer"
        onClick={() => {
            if(!isActive) setIsEditing(true);
        }}
      >
        {/* Container for visuals */}
        <div className={`
            w-80 h-80 flex items-center justify-center relative
            transition-all duration-300
            ${isActive ? 'scale-105' : 'scale-100'}
        `}>
             
             {/* MODE: FOCUS VISUALS (BIG ATOM) */}
             {mode === 'focus' && (
                <>
                    {/* Orbit Rings - Outer */}
                    <div className={`absolute inset-0 rounded-full border border-slate-300 dark:border-slate-700/50 ${isActive ? 'animate-orbit-1' : ''}`}></div>
                    <div className={`absolute inset-0 rounded-full border border-slate-300 dark:border-slate-700/50 rotate-45 ${isActive ? 'animate-orbit-2' : ''}`}></div>
                    <div className={`absolute inset-0 rounded-full border border-slate-300 dark:border-slate-700/50 -rotate-45 ${isActive ? 'animate-orbit-3' : ''}`}></div>
                    <div className={`absolute inset-0 rounded-full border border-slate-300 dark:border-slate-700/50 rotate-90 ${isActive ? 'animate-spin-slow' : ''}`}></div>
                    
                    {/* Electrons - Staggered Animations to prevent collision/disappearing */}
                    {isActive && (
                        <>
                             {/* Electron 1 */}
                             <div className="absolute inset-0 animate-orbit-1" style={{ animationDelay: '0s' }}>
                                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1.5 w-3 h-3 bg-mate-blue dark:bg-neon-blue rounded-full shadow-[0_0_10px_currentColor]"></div>
                             </div>
                             {/* Electron 2 */}
                             <div className="absolute inset-0 animate-orbit-2 rotate-45" style={{ animationDelay: '-1s' }}>
                                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1.5 w-3 h-3 bg-mate-blue dark:bg-neon-blue rounded-full shadow-[0_0_10px_currentColor]"></div>
                             </div>
                             {/* Electron 3 */}
                             <div className="absolute inset-0 animate-orbit-3 -rotate-45" style={{ animationDelay: '-2s' }}>
                                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1.5 w-3 h-3 bg-mate-blue dark:bg-neon-blue rounded-full shadow-[0_0_10px_currentColor]"></div>
                             </div>
                             {/* Electron 4 */}
                             <div className="absolute inset-0 animate-spin-slow rotate-90" style={{ animationDelay: '-3s' }}>
                                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1.5 w-3 h-3 bg-mate-blue dark:bg-neon-blue rounded-full shadow-[0_0_10px_currentColor]"></div>
                             </div>
                        </>
                    )}

                    {/* BIG Nucleus - Background for Time */}
                    <div className="absolute w-64 h-64 rounded-full bg-mate-ink/90 dark:bg-white/10 backdrop-blur-md flex items-center justify-center z-0 shadow-block dark:shadow-[0_0_30px_rgba(0,180,216,0.4)] border-4 border-mate-ink dark:border-neon-blue/30">
                         {/* Core Pulsing Glow - SLOWED DOWN */}
                         <div className={`w-full h-full rounded-full opacity-40 bg-mate-blue dark:bg-neon-blue absolute animate-pulse-slow`}></div>
                         {/* Inner Core particles */}
                         <div className="absolute w-20 h-20 bg-mate-blue dark:bg-neon-blue rounded-full blur-xl opacity-50 animate-pulse-slow"></div>
                    </div>
                </>
             )}

             {/* MODE: BREAK VISUALS (ANTI-CLOCKWISE RUNNER & FILLING LINE) */}
             {mode === 'break' && (
                <>
                     {/* Background Circle for Break Mode (New) */}
                     <div className="absolute w-64 h-64 rounded-full bg-[#14532d] dark:bg-[#052e16] border-4 border-mate-success dark:border-neon-green/30 flex items-center justify-center shadow-[0_0_20px_rgba(16,185,129,0.2)] z-0">
                         <div className="w-full h-full rounded-full opacity-20 bg-mate-success absolute animate-pulse-slow"></div>
                     </div>

                     {/* SVG Track Layer - Flipped to fill Counter-Clockwise */}
                     {/* rotate(-90deg) puts start at 12 o'clock. scaleX(-1) makes dasharray fill CCW */}
                     <svg className="absolute inset-0 w-full h-full" viewBox="0 0 320 320" style={{ transform: 'rotate(-90deg) scaleX(-1)' }}>
                        {/* Dashed Background Track */}
                        <circle
                            cx="160"
                            cy="160"
                            r={radius}
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="4"
                            strokeDasharray="10 10"
                            className="text-slate-300 dark:text-slate-600"
                        />
                     </svg>
                     
                     {/* Runner Container */}
                     <div 
                        className={`absolute inset-0 w-full h-full pointer-events-none ${isActive ? 'transition-transform duration-1000 ease-linear' : ''}`}
                        style={{ 
                            transform: `rotate(${progressPercent * -360}deg)` 
                        }}
                     >
                        {/* Runner Positioned at Top (0 deg) */}
                        <div className="absolute -top-5 left-1/2 -translate-x-1/2 transform text-2xl">
                            🏃
                        </div>
                     </div>
                </>
             )}


            {/* Center Display */}
            <div className={`flex flex-col items-center z-10 p-8 rounded-full transition-all ${mode === 'focus' ? 'bg-transparent' : 'bg-transparent'}`}>
                {isEditing ? (
                    <div className="flex flex-col items-center animate-in zoom-in duration-200" onClick={(e) => e.stopPropagation()}>
                        <span className="text-xs font-bold uppercase text-slate-500 mb-2 dark:text-slate-300 mix-blend-difference">Set Minutes</span>
                        <input
                            ref={inputRef}
                            type="number"
                            value={inputVal}
                            onChange={(e) => setInputVal(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && saveEdit()}
                            className="w-32 bg-transparent text-6xl font-black font-mono text-white dark:text-white text-center focus:outline-none border-b-4 border-white mb-4 py-2 drop-shadow-md"
                        />
                        <button 
                            onClick={saveEdit}
                            className="mt-2 px-6 py-2 bg-white text-black rounded-full text-xs font-bold uppercase flex items-center gap-1 hover:scale-105 transition-transform shadow-lg"
                        >
                            <Save size={14} /> Save
                        </button>
                    </div>
                ) : (
                    <>
                        <span className="text-6xl md:text-7xl font-black font-mono tracking-tighter transition-colors text-white drop-shadow-md">
                            {formatTime(timeLeft)}
                        </span>
                        <span className="text-xs font-bold uppercase tracking-[0.2em] mt-2 flex items-center gap-1 text-slate-400">
                            {isActive 
                                ? (mode === 'focus' ? 'FOCUSING' : 'RECHARGING') 
                                : (timeLeft === 0 
                                    ? (mode === 'focus' ? 'WELL DONE' : 'GRASS TOUCHED') 
                                    : 'TAP TO EDIT'
                                )
                            }
                        </span>
                        {/* Optional Sub-message for completion */}
                        {!isActive && timeLeft === 0 && mode === 'focus' && (
                            <span className="absolute bottom-20 text-sm font-bold text-neon-blue animate-bounce">
                                YOU NAILED IT!
                            </span>
                        )}
                    </>
                )}
            </div>
        </div>
      </div>

      {/* Mode Switcher - Below Timer */}
      <div className="flex bg-white dark:bg-mate-dark-card p-1.5 rounded-2xl border-2 border-mate-ink dark:border-white shadow-block-sm dark:shadow-none mb-8 relative z-20">
        <button 
            onClick={setFocusMode}
            className={`px-6 py-2 rounded-xl font-bold uppercase text-xs transition-all ${mode === 'focus' ? 'bg-mate-ink dark:bg-neon-purple text-white dark:text-black shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'}`}
        >
            Deep Work
        </button>
        <button 
            onClick={setBreakMode}
            className={`px-6 py-2 rounded-xl font-bold uppercase text-xs transition-all ${mode === 'break' ? 'bg-mate-success text-white shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'}`}
        >
            Touch Grass
        </button>
      </div>

      {/* Main Controls */}
      <div className="flex gap-6 relative z-20">
        <button 
            onClick={toggleTimer}
            disabled={isEditing}
            className={`
                w-20 h-20 rounded-full flex items-center justify-center border-4 border-mate-ink dark:border-white shadow-block dark:shadow-[4px_4px_0px_#fff] transition-all hover:-translate-y-1 hover:shadow-block-hover dark:hover:shadow-[6px_6px_0px_#fff] active:translate-y-0 active:shadow-none disabled:opacity-50 disabled:hover:translate-y-0 disabled:hover:shadow-block
                ${isActive ? 'bg-white dark:bg-mate-dark-card text-mate-ink dark:text-white' : 'bg-mate-ink dark:bg-white text-white dark:text-mate-ink'}
            `}
        >
            {isActive ? <Pause size={32} fill="currentColor" /> : <Play size={32} fill="currentColor" className="ml-1" />}
        </button>
        
        <button 
            onClick={resetTimer}
            className="w-20 h-20 bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 rounded-full flex items-center justify-center border-4 border-mate-ink dark:border-slate-500 shadow-block dark:shadow-none hover:bg-white dark:hover:bg-slate-700 transition-all hover:-translate-y-1 active:translate-y-0"
        >
            <RefreshCw size={28} />
        </button>
      </div>

    </div>
  );
};