import React from 'react';
import { Page } from '../types';
import { Home, Zap, BarChart3, Settings } from 'lucide-react';

interface BottomNavProps {
  currentPage: Page;
  setPage: (page: Page) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentPage, setPage }) => {
  const navItems: { page: Page; icon: React.ElementType; label: string }[] = [
    { page: 'home', icon: Home, label: 'Home' },
    { page: 'lockin', icon: Zap, label: 'Lock In' },
    { page: 'stats', icon: BarChart3, label: 'Stats' },
    { page: 'settings', icon: Settings, label: 'Settings' },
  ];

  return (
    <div className="fixed bottom-6 left-0 right-0 z-50 flex justify-center pointer-events-none">
      <div className="bg-white/90 dark:bg-slate-900/80 backdrop-blur-xl border border-slate-200 dark:border-white/10 rounded-full shadow-[0_8px_30px_rgb(0,0,0,0.12)] dark:shadow-[0_0_20px_rgba(0,243,255,0.15)] p-1.5 flex items-center gap-1 pointer-events-auto transition-all duration-300 transform">
        {navItems.map((item) => {
          const isActive = currentPage === item.page;
          const Icon = item.icon;
          
          return (
            <button
              key={item.page}
              onClick={() => setPage(item.page)}
              className={`
                relative flex items-center justify-center w-12 h-12 rounded-full transition-all duration-300
                ${isActive 
                    ? 'bg-mate-ink dark:bg-white text-white dark:text-mate-ink shadow-md scale-110' 
                    : 'text-slate-400 dark:text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
                }
              `}
            >
              <Icon size={20} strokeWidth={isActive ? 3 : 2} />
              
              {isActive && (
                <span className="absolute -top-1 right-0 w-2 h-2 bg-mate-blue dark:bg-neon-blue rounded-full"></span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
