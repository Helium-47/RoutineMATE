import React from 'react';
import { Task } from '../types';
import { Check, Trash2, Repeat, Clock } from 'lucide-react';

interface TaskCardProps {
  task: Task;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
}

export const TaskCard: React.FC<TaskCardProps> = ({ task, onToggle, onDelete }) => {
  return (
    <div 
      className={`
        relative group flex items-center justify-between p-4 mb-3
        border-2 border-mate-ink dark:border-slate-600 rounded-lg shadow-block dark:shadow-none transition-all duration-200
        ${task.completed 
            ? 'bg-slate-100 dark:bg-slate-800 opacity-70' 
            : 'bg-white dark:bg-slate-900 hover:translate-x-1 hover:shadow-block-hover dark:hover:border-white'
        }
      `}
    >
      <div className="flex items-center gap-4 flex-1">
        <button
          onClick={() => onToggle(task.id)}
          className={`
            w-10 h-10 flex-shrink-0 rounded-md border-2 border-mate-ink dark:border-slate-400 flex items-center justify-center
            transition-colors duration-200
            ${task.completed ? 'bg-mate-ink dark:bg-white' : 'bg-white dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700'}
          `}
        >
          {task.completed ? <Check size={20} className="text-white dark:text-black" strokeWidth={4} /> : null}
        </button>
        
        <div className="flex flex-col">
            <div className="flex items-center gap-2">
                <span className="text-xl">{task.emoji}</span>
                <span className={`text-base font-bold font-display text-mate-ink dark:text-white ${task.completed ? 'line-through text-slate-400 dark:text-slate-500' : ''}`}>
                    {task.text}
                </span>
            </div>
            
            <div className="flex items-center gap-3 mt-1">
                {task.type === 'daily' && (
                    <span className="text-[10px] font-bold text-mate-blue dark:text-neon-blue uppercase tracking-widest flex items-center gap-1">
                        <Repeat size={10} /> Routine
                    </span>
                )}
                {task.duration && (
                    <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest flex items-center gap-1 bg-slate-100 dark:bg-slate-800 px-1.5 rounded border border-slate-200 dark:border-slate-700">
                        <Clock size={10} /> {task.duration}
                    </span>
                )}
            </div>
        </div>
      </div>

      <button 
        onClick={(e) => {
            e.stopPropagation();
            onDelete(task.id);
        }}
        className="opacity-0 group-hover:opacity-100 transition-opacity p-2 hover:bg-red-100 dark:hover:bg-red-900/50 rounded text-red-600 dark:text-red-400"
      >
        <Trash2 size={18} />
      </button>
    </div>
  );
};
