import React, { useState } from 'react';
import { getGeminiRoast } from '../services/geminiService';
import { Task, ViewMode } from '../types';
import { Zap, X, Flame } from 'lucide-react';

interface GeminiJudgeProps {
  tasks: Task[];
  viewMode: ViewMode;
}

export const GeminiJudge: React.FC<GeminiJudgeProps> = ({ tasks, viewMode }) => {
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ text: string, mood: string } | null>(null);

  const handleJudge = async () => {
    setLoading(true);
    setMessage(null);
    const result = await getGeminiRoast(tasks, viewMode);
    setMessage(result);
    setLoading(false);
  };

  return (
    <div className="w-full mb-6">
      {!message && !loading && (
        <button
          onClick={handleJudge}
          className="w-full bg-mate-ink dark:bg-white text-white dark:text-mate-ink py-3 rounded-lg border-2 border-mate-ink dark:border-white hover:bg-mate-blue dark:hover:bg-slate-200 font-bold font-display shadow-block dark:shadow-block-dark transition-all flex items-center justify-center gap-2 uppercase tracking-wide text-sm"
        >
          <Zap size={18} className="text-yellow-400 dark:text-mate-ink fill-yellow-400 dark:fill-mate-ink" />
          {viewMode === 'daily' ? "Hype My Routine" : "Motivate Me"}
        </button>
      )}

      {loading && (
        <div className="w-full bg-mate-bg dark:bg-slate-900 p-3 rounded-lg border-2 border-mate-ink dark:border-slate-500 border-dashed flex items-center justify-center gap-2">
          <Flame size={18} className="animate-bounce text-mate-orange" />
          <span className="text-sm font-bold font-mono text-mate-ink dark:text-white uppercase">Cooking up motivation...</span>
        </div>
      )}

      {message && (
        <div 
            className="relative w-full p-4 rounded-lg border-2 border-mate-ink dark:border-white shadow-block dark:shadow-block-dark transition-all"
            style={{ backgroundColor: message.mood }} 
        >
          <button 
            onClick={() => setMessage(null)}
            className="absolute top-2 right-2 p-1 rounded hover:bg-black/20 text-mate-ink"
          >
            <X size={16} />
          </button>
          <div className="flex items-center gap-2 mb-2 opacity-80">
            <div className="w-2 h-2 bg-mate-ink rounded-full animate-pulse"></div>
            <h3 className="font-bold text-xs uppercase font-mono text-mate-ink">Coach Says</h3>
          </div>
          <p className="text-lg font-bold font-display text-mate-ink leading-tight">"{message.text}"</p>
        </div>
      )}
    </div>
  );
};
