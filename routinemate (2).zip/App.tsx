import React, { useState, useEffect, useCallback } from 'react';
import { Task, ViewMode, TaskType, Page } from './types';
import { TaskCard } from './components/TaskCard';
import { GeminiJudge } from './components/GeminiJudge';
import { BottomNav } from './components/BottomNav';
import { LockInPage } from './components/LockInPage';
import { StatsPage } from './components/StatsPage';
import { SettingsPage } from './components/SettingsPage';
import { Plus, Sun, ListTodo, Calendar, Clock, X, Repeat, User, ArrowRight, Zap, Star, AlertTriangle } from 'lucide-react';

const EMOJIS = [
  // Weather & Nature
  '☀️', '🌤️', '⛅️', '☁️', '🌦️', '🌧️', '⛈️', '🌩️', '🌨️', '❄️', '💨', '🌪️', '🌫️', '🌈', '☂️', '☔️', '🌊', '🌙', '🌑', '🌓', '🌔', '🌕', '⭐️', '🌟', '✨', '⚡️', '🔥', '💧', '🌱', '🌿', '☘️', '🍀', '🌵', '🌴', '🌳', '🌲', '🌸', '🌹', '🌻',
  '⚽️', '🏀', '🏈', '⚾️', '🥎', '🎾', '🏐', '🏉', '🎱', '🏓', '🏸', '🏒', '🏑', '🥍', '🏏', '🥊', '🥋', '🥅', '⛳️', '⛸️', '🎣', '🤿', '🎽', '🎿', '🛷', '🥌', '🎯', '🪀', '🪁', '🎳', '🤺', '🤼', '🤸', '⛹️', '🤾', '🧗', '🚵', '🚴', '🏆', '🥇', '🥈', '🥉', '🧘', '🏄', '🏊', '🤽', '🚣', '🏇',
  '👓', '🕶️', '🥽', '🥼', '🦺', '👔', '👕', '👖', '🧣', '🧤', '🧥', '🧦', '👗', '👘', '🥻', '🩱', '🩲', '🩳', '👙', '👚', '👛', '👜', '👝', '🎒', '👞', '👟', '🥾', '🥿', '👠', '👡', '🩰', '👢', '👑', '👒', '🎩', '🎓', '🧢', '⛑️', '💄', '💍', '💎',
  '🚿', '🛁', '🧼', '🪥', '🪒', '🧴', '🧻', '🧽', '💄', '💅', '💇', '💆', '🧖', '🛌', '🧘',
  '💡', '🕯️', '🔦', '🏮', '🧱', '🪜', '🪞', '🪟', '🦠', '🧬', '🔭', '🔬', '📡', '🩺', '💊', '🩹', '🩸', '🦠', '🧫', '🧪', '🌡️', '🧹', '🧺', '🧻', '🚽', '🚰', '📚', '📖', '🖊️', '🖋️', '✒️', '📝', '✏️', '🖍️', '🖌️', '🔍', '🔎', '🔏', '🔐', '🔒', '🔓', '❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔', '💻', '🖥️', '🖨️', '🖱️', '🖲️', '🕹️', '🗜️', '💽', '💾', '💿', '📀', '📼', '📷', '📸', '📹', '🎥', '📽️', '🎞️', '📞', '☎️', '📟', '📠', '📺', '📻', '🎙️', '🎚️', '🎛️', '🧭', '⏱️', '⏲️', '⏰', '🕰️', '⌛️', '⏳', '📡', '🔋', '🔌', '💡', '🔦', '🕯️',
  '🍏', '🍎', '🍐', '🍊', '🍋', '🍌', '🍉', '🍇', '🍓', '🫐', '🍈', '🍒', '🍑', '🥭', '🍍', '🥥', '🥝', '🍅', '🥑', '🥦', '🥬', '🥒', '🌶️', '🌽', '🥕', '🥔', '🍠', '🥐', '🥯', '🍞', '🥖', '🥨', '🧀', '🥚', '🍳', '🧈', '🥞', '🧇', '🥓', '🥩', '🍗', '🍖', '🦴', '🌭', '🍔', '🍟', '🍕', '🫓', '🥪', '🥙', '🧆', '🌮', '🌯', '🫔', '🥗', '🥘', '🫕', '🥫', '🍝', '🍜', '🍲', '🍛', '🍣', '🍱', '🥟', '🦪', '🍤', '🍙', '🍚', '🍘', '🍥', '🥠', '🥮', '🍢', '🍡', '🍧', '🍨', '🍦', '🥧', '🧁', '🍰', '🎂', '🍮', '🍭', '🍬', '🍫', '🍿', '🍩', '🍪', '🌰', '🥜', '🍯', '🥛', '🍼', '☕️', '🍵', '🧃', '🥤', '🧋', '🍶', '🍺', '🍻', '🥂', '🍷', '🥃', '🍸', '🍹', '🧉', '🍾', '🧊', '🥄', '🍴', '🍽️', '🥣', '🥡', '🥢', '🧂',
  '🚗', '🚕', '🚙', '🚌', '🚎', '🏎️', '🚓', '🚑', '🚒', '🚐', '🛻', '🚚', '🚛', '🚜', '🛵', '🏍️', '🛺', '🚔', '🚍', '🚘', '🚖', '🚡', '🚠', '🚟', '🚃', '🚋', '🚞', '🚝', '🚄', '🚅', '🚈', '🚂', '🚆', '🚇', '🚊', '🚉', '✈️', '🛫', '🛬', '🛩️', '💺', '🛰️', '🚀', '🛸', '🚁', '🛶', '⛵️', '🚤', '🛥️', '🛳️', '⛴️', '🚢', '⚓️', '🚧', '⛽️', '🚏', '🚦', '🚥', '🛑', '🎡', '🎢', '🎠', '🏗️', '🌁', '🗼', '🏭', '⛲️', '🎑', '⛰️', '🏔️', '🗻', '🌋', '🗾', '🏕️', '⛺️', '🏞️', '🛣️', '🛤️', '🌅', '🌄', '🏜️', '🏖️', '🏝️', '🌇', '🌆', '🏙️', '🌃', '🌉', '🌌', '🌠', '🎇', '🎆', '🏘️', '🏰', '🏯', '🏟️', '🗽', '🏠', '🏡', '🏚️', '🏢', '🏬', '🏣', '🏤', '🏥', '🏦', '🏨', '🏪', '🏫', '🏩', '💒', '🏛️', '⛪️', '🕌', '🕍', '🕋', '⛩️',
  '🧳', '☂️', '🌂', '🧵', '🧶', '👓', '🕶️', '🥽', '🥼', '🦺', '👔', '👕', '👖', '🧣', '🧤', '🧥', '🧦', '👗', '👘', '🥻', '🩱', '🩲', '🩳', '👙', '👚', '👛', '👜', '👝', '🎒', '👞', '👟', '🥾', '🥿', '👠', '👡', '🩰', '👢', '👑', '👒', '🎩', '🎓', '🧢', '⛑️', '💄', '💍', '💎'
];

const HYPE_PHRASES = [
  "MISSION\nCOMPLETE"
];

function App() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [viewMode, setViewMode] = useState<ViewMode>('daily');
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  // Navigation State
  const [currentPage, setCurrentPage] = useState<Page>('home');
  
  // Theme State
  const [isDarkMode, setIsDarkMode] = useState(false);

  // User Data
  const [username, setUsername] = useState<string>('');
  const [startDate, setStartDate] = useState<number>(Date.now());
  const [totalAura, setTotalAura] = useState<number>(0); // Persistent Aura Score
  const [lifetimeCompleted, setLifetimeCompleted] = useState<number>(0); // Persistent Task Count
  const [isOnboarding, setIsOnboarding] = useState(false);
  const [tempName, setTempName] = useState('');
  
  // Welcome Toast State
  const [showWelcome, setShowWelcome] = useState(false);

  // New Task Form State
  const [newTaskText, setNewTaskText] = useState('');
  const [newTaskEmoji, setNewTaskEmoji] = useState(EMOJIS[0]);
  const [newTaskDuration, setNewTaskDuration] = useState('');
  const [newTaskType, setNewTaskType] = useState<TaskType>('daily');
  const [formError, setFormError] = useState('');
  
  // Celebration State
  const [showCelebration, setShowCelebration] = useState(false);
  const [hypeMessage, setHypeMessage] = useState('');
  
  // Track the last user action to prevent celebration on navigation/load
  const [lastAction, setLastAction] = useState<'init' | 'toggle' | 'nav' | 'add' | 'delete' | 'celebrated'>('init');

  // Initial Load (User & Tasks & Theme & Aura & Lifetime Stats)
  useEffect(() => {
    // Check User
    const savedUser = localStorage.getItem('routinemate_username');
    if (savedUser) {
        setUsername(savedUser);
        // Show welcome toast
        setShowWelcome(true);
        setTimeout(() => setShowWelcome(false), 3000);
    } else {
        setIsOnboarding(true);
    }

    // Check Start Date
    const savedStart = localStorage.getItem('routinemate_start_date');
    if (savedStart) {
        setStartDate(parseInt(savedStart, 10));
    } else {
        const now = Date.now();
        localStorage.setItem('routinemate_start_date', now.toString());
        setStartDate(now);
    }

    // Check Aura
    const savedAura = localStorage.getItem('routinemate_aura');
    if (savedAura) {
        setTotalAura(parseInt(savedAura, 10));
    }

    // Check Lifetime Completed Tasks
    const savedLifetime = localStorage.getItem('routinemate_lifetime_completed');
    if (savedLifetime) {
        setLifetimeCompleted(parseInt(savedLifetime, 10));
    }

    // Check Theme
    const savedTheme = localStorage.getItem('routinemate_theme');
    if (savedTheme === 'dark') {
      setIsDarkMode(true);
      document.documentElement.classList.add('dark');
    } else {
      setIsDarkMode(false);
      document.documentElement.classList.remove('dark');
    }

    // Check Tasks & Perform Daily Reset
    const saved = localStorage.getItem('routinemate_tasks');
    if (saved) {
      const parsedTasks: Task[] = JSON.parse(saved);
      const today = new Date().toDateString();
      
      const processedTasks = parsedTasks.map(t => {
        // If it's a daily task, finished, but finished on a previous day -> RESET IT
        if (t.type === 'daily' && t.completed && t.lastCompletedAt) {
          const lastDate = new Date(t.lastCompletedAt).toDateString();
          if (lastDate !== today) {
            return { ...t, completed: false, lastCompletedAt: null };
          }
        }
        return t;
      });
      setTasks(processedTasks);
    } else {
        const oldSaved = localStorage.getItem('doodledo_tasks');
        if (oldSaved) {
            setTasks(JSON.parse(oldSaved));
        }
    }
  }, []);

  // Save Tasks to LocalStorage
  useEffect(() => {
    if (tasks.length > 0) {
        localStorage.setItem('routinemate_tasks', JSON.stringify(tasks));
    }
  }, [tasks]);

  // Save Aura to LocalStorage
  useEffect(() => {
    localStorage.setItem('routinemate_aura', totalAura.toString());
  }, [totalAura]);

  // Save Lifetime Stats
  useEffect(() => {
    localStorage.setItem('routinemate_lifetime_completed', lifetimeCompleted.toString());
  }, [lifetimeCompleted]);

  const toggleTheme = () => {
    setIsDarkMode(prev => {
      const newVal = !prev;
      if (newVal) {
        document.documentElement.classList.add('dark');
        localStorage.setItem('routinemate_theme', 'dark');
      } else {
        document.documentElement.classList.remove('dark');
        localStorage.setItem('routinemate_theme', 'light');
      }
      return newVal;
    });
  };

  const handleOnboardingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (tempName.trim()) {
        const name = tempName.trim();
        setUsername(name);
        localStorage.setItem('routinemate_username', name);
        localStorage.setItem('routinemate_start_date', Date.now().toString());
        setIsOnboarding(false);
        setTempName('');
    }
  };

  const addTask = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!newTaskText.trim()) return;

    // Validation: Check for duplicate daily tasks
    if (newTaskType === 'daily') {
        const isDuplicate = tasks.some(t => 
            t.type === 'daily' && 
            t.text.trim().toLowerCase() === newTaskText.trim().toLowerCase()
        );
        
        if (isDuplicate) {
            setFormError('You already have a daily routine with this name!');
            return;
        }
    }

    // Append 'm' if user just typed a number for minutes to keep UI consistent
    let durationString = newTaskDuration;
    if (durationString && /^\d+$/.test(durationString)) {
        durationString += 'm';
    }

    const newTask: Task = {
      id: crypto.randomUUID(),
      text: newTaskText,
      type: newTaskType,
      completed: false,
      lastCompletedAt: null,
      emoji: newTaskEmoji,
      duration: durationString || undefined,
      createdAt: Date.now(),
    };

    setTasks(prev => [newTask, ...prev]);
    setLastAction('add');
    resetForm();
    setIsModalOpen(false);
  };

  const resetForm = () => {
    setNewTaskText('');
    setNewTaskEmoji(EMOJIS[Math.floor(Math.random() * EMOJIS.length)]);
    setNewTaskDuration('');
    setNewTaskType(viewMode);
    setFormError('');
  };

  const toggleTask = useCallback((id: string) => {
    setLastAction('toggle');
    setTasks(prev => prev.map(t => {
      if (t.id === id) {
        const isNowCompleted = !t.completed;
        
        // Update Persistent Aura & Lifetime Count
        setTotalAura(currentAura => {
            if (isNowCompleted) {
                return currentAura + 100;
            } else {
                return Math.max(0, currentAura - 100); // Prevent negative aura
            }
        });

        setLifetimeCompleted(current => {
            if (isNowCompleted) return current + 1;
            return Math.max(0, current - 1);
        });

        return {
          ...t,
          completed: isNowCompleted,
          lastCompletedAt: isNowCompleted ? new Date().toISOString() : null
        };
      }
      return t;
    }));
  }, []);

  const deleteTask = useCallback((id: string) => {
    setLastAction('delete');
    setTasks(prev => prev.filter(t => t.id !== id));
    // Note: Deleting a task does NOT remove its aura or reduce lifetime count.
  }, []);

  const clearData = () => {
    // Completely wipe all data
    localStorage.removeItem('routinemate_tasks');
    localStorage.removeItem('routinemate_username');
    localStorage.removeItem('routinemate_start_date');
    localStorage.removeItem('routinemate_aura');
    localStorage.removeItem('routinemate_lifetime_completed');
    
    // Reset State
    setTasks([]);
    setUsername('');
    setStartDate(Date.now());
    setTotalAura(0);
    setLifetimeCompleted(0);
    
    // Trigger Onboarding
    setIsOnboarding(true);
    setLastAction('delete');
  };

  const handleSetViewMode = (mode: ViewMode) => {
    setViewMode(mode);
    setLastAction('nav');
  };

  // Sort tasks: Uncompleted first, Completed last
  const filteredTasks = tasks
    .filter(t => t.type === viewMode)
    .sort((a, b) => Number(a.completed) - Number(b.completed));

  const completedCount = filteredTasks.filter(t => t.completed).length;
  const progress = filteredTasks.length > 0 ? (completedCount / filteredTasks.length) * 100 : 0;

  // Trigger Celebration
  useEffect(() => {
    // Only celebrate if progress is 100%, we have tasks, AND the user just toggled a task.
    if (progress === 100 && filteredTasks.length > 0 && lastAction === 'toggle') {
      const phrase = HYPE_PHRASES[Math.floor(Math.random() * HYPE_PHRASES.length)];
      setHypeMessage(phrase);
      setShowCelebration(true);
      setLastAction('celebrated'); 
    }
  }, [progress, filteredTasks.length, lastAction]);

  if (isOnboarding) {
    return (
        <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6">
            <div className="w-full max-w-sm bg-white p-8 rounded-lg border-2 border-mate-ink shadow-block animate-in fade-in zoom-in duration-300">
                <div className="flex justify-center mb-6">
                    <div className="bg-mate-blue p-4 rounded-full border-2 border-mate-ink shadow-block-sm">
                        <User className="text-white w-10 h-10" strokeWidth={2.5} />
                    </div>
                </div>
                <h1 className="text-3xl font-black font-display text-center mb-2 uppercase text-mate-ink">Identify Yourself</h1>
                <p className="text-center text-slate-500 font-mono text-sm mb-8">Who is locking in today?</p>
                <form onSubmit={handleOnboardingSubmit} className="space-y-4">
                    <input 
                        autoFocus
                        type="text" 
                        value={tempName}
                        onChange={(e) => setTempName(e.target.value)}
                        placeholder="Enter your codename..."
                        className="w-full p-3 text-lg font-bold border-2 border-mate-ink rounded bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-mate-blue placeholder:font-normal text-center text-mate-ink"
                    />
                    <button 
                        type="submit"
                        disabled={!tempName.trim()}
                        className="w-full py-4 bg-mate-ink text-white font-black font-display uppercase tracking-widest rounded border-2 border-mate-ink shadow-block hover:shadow-block-hover hover:-translate-y-1 transition-all disabled:opacity-50 disabled:hover:translate-y-0 disabled:hover:shadow-block flex items-center justify-center gap-2"
                    >
                        Start Grinding <ArrowRight size={20} />
                    </button>
                </form>
            </div>
        </div>
    )
  }

  return (
    <div className="min-h-screen pb-24 font-sans text-mate-ink dark:text-white selection:bg-mate-blue selection:text-white transition-colors relative overflow-x-hidden">
      
      {/* Welcome Toast */}
      {showWelcome && (
          <div className="fixed top-0 left-0 right-0 z-[60] flex justify-center pointer-events-none">
              <div className="mt-4 bg-mate-ink dark:bg-white text-white dark:text-mate-ink px-6 py-3 rounded-full shadow-xl animate-welcome-slide flex items-center gap-2 font-bold font-display uppercase border-2 border-white dark:border-mate-ink">
                  <span className="text-xl">👋</span> 
                  <span>Welcome {username} back</span>
              </div>
          </div>
      )}

      {/* GEN Z CELEBRATION OVERLAY */}
      {showCelebration && (
        <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[#facc15] overflow-hidden cursor-pointer" onClick={() => setShowCelebration(false)}>
            <style>{`
                @keyframes gravity-fall {
                    0% { transform: translateY(-120vh) rotate(var(--rot-start)); opacity: 1; }
                    70% { transform: translateY(0) rotate(var(--rot-end)); }
                    85% { transform: translateY(-20px) rotate(var(--rot-end)); }
                    100% { transform: translateY(0) rotate(var(--rot-end)); opacity: 1; }
                }
            `}</style>
            
            {/* Background Dot Pattern */}
            <div className="absolute inset-0 opacity-30 bg-[radial-gradient(#000_2px,transparent_2px)] [background-size:24px_24px] pointer-events-none"></div>

            {/* Dropping Gen Z Phrases */}
            {["🔥 Cooked the task", "🥱 Easy Huh?", "🔒 Lock in Successful", "💀 Wasted", "💍 Put a ring on it", "🧢 No Cap", "💅 Slay", "💊 Chill Pill", "📉 Opps down", "🐐 GOAT status", "💸 Bag secured", "🤫 MOGGED"].map((phrase, i) => {
                 const randomSeed = (i * 12345) % 100;
                 const leftPos = (randomSeed / 100) * 90;
                 const bottomPos = (i % 6) * 4;
                 const rotStart = (i % 2 === 0 ? -1 : 1) * (10 + Math.random() * 20);
                 const rotEnd = ((i * 99) % 60) - 30;

                 return (
                     <div 
                        key={i}
                        className="absolute z-10 bg-white border-4 border-black px-3 py-2 font-black font-mono text-black uppercase shadow-[6px_6px_0px_#000] text-lg md:text-2xl whitespace-nowrap"
                        style={{
                            left: `${leftPos}%`,
                            bottom: `${bottomPos}%`,
                            '--rot-start': `${rotStart}deg`,
                            '--rot-end': `${rotEnd}deg`,
                            animation: `gravity-fall 0.8s cubic-bezier(0.25, 1, 0.5, 1) forwards`,
                            animationDelay: `${i * 0.15}s`,
                            transform: 'translateY(-120vh)' // Initial state
                        } as any}
                     >
                        {phrase}
                     </div>
                )
            })}

            {/* Main Center Content */}
            <div className="relative z-30 flex flex-col items-center gap-8 mb-40 pointer-events-none">
                <h1 className="text-6xl md:text-9xl font-black font-display italic text-white leading-none text-center drop-shadow-[8px_8px_0px_#000] tracking-tighter animate-in zoom-in duration-300">
                    MISSION<br/>COMPLETE
                </h1>
                
                <div className="bg-white border-4 border-black px-8 py-3 rounded-full transform -rotate-3 animate-bounce shadow-[8px_8px_0px_#000]">
                    <span className="text-3xl md:text-5xl font-black font-mono text-black tracking-tighter">
                        +9999 Aura ✨
                    </span>
                </div>
            </div>

            {/* OK Button */}
            <div className="absolute z-50 bottom-32 md:bottom-24 animate-in slide-in-from-bottom-20 fade-in duration-500 delay-1000 fill-mode-forwards opacity-0" style={{ animationFillMode: 'forwards' }}>
                 <button 
                    onClick={(e) => {
                        e.stopPropagation();
                        setShowCelebration(false);
                    }}
                    className="px-16 py-4 bg-black hover:bg-slate-800 text-white font-black font-display text-2xl uppercase tracking-widest border-4 border-white shadow-[8px_8px_0px_#000] hover:translate-x-1 hover:translate-y-1 hover:shadow-none transition-all active:scale-95 transform -rotate-1 hover:rotate-0"
                >
                    OK
                </button>
            </div>
        </div>
      )}

      {/* Main Content Area based on Tab - Wrapped in a Transition Div */}
      <div className="pt-6 relative">
        <div key={currentPage} className="animate-page-enter">
            {currentPage === 'home' && (
            <>
                {/* Header */}
                <header className="max-w-md mx-auto p-6 pb-2">
                    <div className="flex justify-between items-end mb-8 border-b-4 border-mate-ink dark:border-white pb-4 transition-colors">
                    <div>
                        <h1 className="text-3xl font-black font-display tracking-tight text-mate-ink dark:text-white uppercase leading-none">
                        Routine<span className="text-mate-blue dark:text-neon-blue dark:text-neon-glow">Mate</span>
                        </h1>
                        <p className="text-[10px] font-bold font-mono text-slate-500 dark:text-slate-400 uppercase tracking-widest mt-1.5 flex items-center gap-1">
                            HQ of {username || 'The Operator'}
                        </p>
                    </div>
                    <div className="text-right">
                        <div className="text-xs font-black bg-mate-orange dark:bg-neon-purple text-white border-2 border-mate-ink dark:border-white px-2 py-1 shadow-block-sm dark:shadow-block-dark-sm transform rotate-2">
                        {new Date().toLocaleDateString(undefined, { weekday: 'short', month: 'numeric', day: 'numeric'})}
                        </div>
                    </div>
                    </div>

                    {/* Dashboard Stats / Progress */}
                    <div className="bg-white dark:bg-mate-dark-card border-2 border-mate-ink dark:border-white rounded-lg p-4 shadow-block dark:shadow-block-dark mb-6 relative overflow-hidden transition-all">
                        <div className="flex justify-between items-center mb-2 z-10 relative">
                            <span className="font-bold font-mono text-xs uppercase text-slate-500 dark:text-slate-400">Completion Rate</span>
                            <span className="font-black font-display text-xl text-mate-ink dark:text-white">{Math.round(progress)}%</span>
                        </div>
                        <div className="w-full h-3 bg-slate-100 dark:bg-slate-800 border-2 border-mate-ink dark:border-white rounded-full overflow-hidden">
                            <div 
                                className="h-full bg-mate-blue dark:bg-neon-blue transition-all duration-500 ease-out border-r-2 border-mate-ink dark:border-white" 
                                style={{ width: `${progress}%` }}
                            />
                        </div>
                    </div>

                    {/* View Toggles */}
                    <div className="flex bg-white dark:bg-mate-dark-card p-1 rounded-lg border-2 border-mate-ink dark:border-white shadow-block dark:shadow-block-dark mb-6 transition-all">
                    <button 
                        onClick={() => handleSetViewMode('daily')}
                        className={`flex-1 py-2 px-4 rounded font-bold text-sm flex items-center justify-center gap-2 transition-all font-display uppercase ${viewMode === 'daily' ? 'bg-mate-ink dark:bg-white text-white dark:text-mate-ink shadow-sm' : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800'}`}
                    >
                        <Sun size={16} /> Daily
                    </button>
                    <div className="w-0.5 bg-slate-200 dark:bg-slate-700 my-1 mx-1"></div>
                    <button 
                        onClick={() => handleSetViewMode('todo')}
                        className={`flex-1 py-2 px-4 rounded font-bold text-sm flex items-center justify-center gap-2 transition-all font-display uppercase ${viewMode === 'todo' ? 'bg-mate-blue dark:bg-neon-blue text-white dark:text-mate-ink shadow-sm' : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800'}`}
                    >
                        <ListTodo size={16} /> To-Do
                    </button>
                    </div>

                    {/* Gemini Coach */}
                    {filteredTasks.length > 0 && (
                    <GeminiJudge tasks={tasks} viewMode={viewMode} />
                    )}

                </header>

                {/* Task List */}
                <main className="max-w-md mx-auto px-6 space-y-2 pb-24">
                    {filteredTasks.length === 0 && (
                        <div className="text-center py-10 opacity-50">
                            <p className="font-mono text-xs uppercase font-bold text-slate-500 dark:text-slate-400">No tasks here yet.</p>
                            <p className="font-display text-lg font-bold text-mate-ink dark:text-white mt-1">Time to add something?</p>
                        </div>
                    )}
                    {filteredTasks.map(task => (
                        <TaskCard 
                            key={task.id} 
                            task={task} 
                            onToggle={toggleTask} 
                            onDelete={deleteTask} 
                        />
                    ))}
                </main>
            </>
            )}

            {currentPage === 'lockin' && <LockInPage />}
            
            {currentPage === 'stats' && <StatsPage tasks={tasks} startDate={startDate} totalAura={totalAura} lifetimeCompleted={lifetimeCompleted} />}
            
            {currentPage === 'settings' && <SettingsPage isDarkMode={isDarkMode} toggleTheme={toggleTheme} clearData={clearData} />}
        </div>
      </div>

      <BottomNav currentPage={currentPage} setPage={setCurrentPage} />
      
      {/* Floating Add Button - Positioned absolutely relative to center to sit next to the nav pill */}
      <div className="fixed bottom-6 left-0 right-0 z-50 flex justify-center pointer-events-none">
          <button
              onClick={() => {
                  resetForm();
                  setIsModalOpen(true);
              }}
              // ml-36 (144px) offsets it from the center. 
              // The nav pill width is roughly 220px, so 110px from center is the edge.
              className="absolute bottom-2 left-1/2 ml-36 md:ml-40 w-12 h-12 bg-mate-blue dark:bg-neon-blue text-white dark:text-mate-ink border-2 border-mate-ink dark:border-white rounded-full shadow-block dark:shadow-block-dark flex items-center justify-center hover:-translate-y-1 hover:shadow-block-hover dark:hover:shadow-block-dark-hover transition-all pointer-events-auto active:translate-y-0 active:shadow-block dark:active:shadow-block-dark"
          >
              <Plus size={24} strokeWidth={3} />
          </button>
      </div>

      {/* Add Task Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/80 z-[60] flex items-center justify-center p-4 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white dark:bg-mate-dark-card w-full max-w-md p-6 rounded-lg border-2 border-mate-ink dark:border-white shadow-block dark:shadow-block-dark animate-in fade-in zoom-in duration-200 my-8">
            <div className="flex justify-between items-center mb-6 border-b-2 border-slate-100 dark:border-slate-700 pb-2">
                <h2 className="text-xl font-black font-display uppercase flex items-center gap-2 text-mate-ink dark:text-white">
                    <Calendar size={20} />
                    Add Entry
                </h2>
                <button onClick={() => setIsModalOpen(false)} className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded dark:text-white">
                    <X size={20} />
                </button>
            </div>
            
            <form onSubmit={addTask}>
                
                {formError && (
                    <div className="mb-4 p-3 bg-red-100 dark:bg-red-900/30 border-l-4 border-red-500 text-red-700 dark:text-red-300 text-xs font-bold font-mono animate-pulse flex items-center gap-2">
                        <AlertTriangle size={14} />
                        {formError}
                    </div>
                )}

                {/* Task Type Selector */}
                <div className="flex gap-2 mb-4">
                    <button
                        type="button"
                        onClick={() => setNewTaskType('daily')}
                        className={`flex-1 py-3 px-2 rounded border-2 flex items-center justify-center gap-1.5 font-bold font-display uppercase text-[11px] sm:text-xs transition-all ${
                            newTaskType === 'daily' 
                                ? 'bg-mate-ink dark:bg-white text-white dark:text-mate-ink border-mate-ink dark:border-white shadow-block-sm dark:shadow-block-dark-sm ring-1 ring-mate-ink dark:ring-white' 
                                : 'bg-white dark:bg-mate-dark-card text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-mate-ink dark:hover:border-white'
                        }`}
                    >
                        <Repeat size={14} className={newTaskType === 'daily' ? 'text-mate-orange' : ''} /> 
                        Daily Repeat
                    </button>
                    <button
                        type="button"
                        onClick={() => setNewTaskType('todo')}
                        className={`flex-1 py-3 px-2 rounded border-2 flex items-center justify-center gap-1.5 font-bold font-display uppercase text-[11px] sm:text-xs transition-all ${
                            newTaskType === 'todo' 
                                ? 'bg-mate-blue dark:bg-neon-blue text-white dark:text-mate-ink border-mate-blue dark:border-neon-blue shadow-block-sm dark:shadow-block-dark-sm ring-1 ring-mate-blue dark:ring-neon-blue' 
                                : 'bg-white dark:bg-mate-dark-card text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-mate-blue dark:hover:border-neon-blue'
                        }`}
                    >
                        <ListTodo size={14} className={newTaskType === 'todo' ? 'text-white dark:text-mate-ink' : ''} /> 
                        One-Time Task
                    </button>
                </div>

                {/* Task Name */}
                <div className="mb-4">
                    <label className="block text-xs font-bold font-mono uppercase text-slate-500 dark:text-slate-400 mb-1">Task Name</label>
                    <input
                        autoFocus
                        type="text"
                        value={newTaskText}
                        onChange={(e) => {
                            setNewTaskText(e.target.value);
                            setFormError('');
                        }}
                        placeholder="e.g. Morning Run, Submit Report..."
                        className="w-full p-3 text-base font-bold border-2 border-mate-ink dark:border-slate-600 rounded bg-slate-50 dark:bg-slate-800 dark:text-white focus:bg-white dark:focus:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-mate-blue dark:focus:ring-neon-blue focus:border-mate-blue dark:focus:border-neon-blue placeholder:font-normal placeholder:text-slate-400 dark:placeholder:text-slate-500"
                    />
                </div>

                {/* Duration Picker */}
                <div className="mb-4">
                    <label className="block text-xs font-bold font-mono uppercase text-slate-500 dark:text-slate-400 mb-2 flex items-center gap-1">
                        <Clock size={12} /> Duration <span className="opacity-50 font-normal ml-1 lowercase">(Minutes - Optional)</span>
                    </label>
                    <input 
                        type="text"
                        inputMode="numeric"
                        value={newTaskDuration}
                        onChange={(e) => {
                            const val = e.target.value;
                            // Only allow digits
                            if (/^\d*$/.test(val)) {
                                setNewTaskDuration(val);
                            }
                        }}
                        placeholder="e.g. 30"
                        className="w-full p-3 text-base font-bold border-2 border-mate-ink dark:border-slate-600 rounded bg-slate-50 dark:bg-slate-800 dark:text-white focus:bg-white dark:focus:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-mate-blue dark:focus:ring-neon-blue focus:border-mate-blue dark:focus:border-neon-blue placeholder:font-normal placeholder:text-slate-400 dark:placeholder:text-slate-500"
                    />
                </div>

                {/* Emoji Picker */}
                <div className="mb-6">
                    <label className="block text-xs font-bold font-mono uppercase text-slate-500 dark:text-slate-400 mb-2 flex justify-between">
                        <span>Choose Icon</span>
                        <span className="text-[10px] text-slate-400">Scroll for more</span>
                    </label>
                    <div className="grid grid-cols-7 gap-2 h-48 overflow-y-auto p-2 border-2 border-slate-200 dark:border-slate-700 rounded-lg bg-slate-50 dark:bg-slate-800 scrollbar-thin scrollbar-thumb-slate-300 dark:scrollbar-thumb-slate-600">
                        {EMOJIS.map((emoji, idx) => (
                            <button
                                key={`${emoji}-${idx}`}
                                type="button"
                                onClick={() => setNewTaskEmoji(emoji)}
                                className={`h-10 w-10 flex items-center justify-center text-xl rounded border transition-all ${newTaskEmoji === emoji ? 'bg-white dark:bg-slate-600 border-mate-ink dark:border-white shadow-block-sm dark:shadow-block-dark-sm scale-110 z-10' : 'bg-transparent border-transparent hover:bg-white dark:hover:bg-slate-700 hover:border-slate-300 dark:hover:border-slate-600'}`}
                            >
                                {emoji}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="flex gap-3">
                    <button 
                        type="button" 
                        onClick={() => setIsModalOpen(false)}
                        className="flex-1 py-3 font-bold font-display uppercase text-sm border-2 border-mate-ink dark:border-white text-mate-ink dark:text-white rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    >
                        Cancel
                    </button>
                    <button 
                        type="submit" 
                        className="flex-1 py-3 font-bold font-display uppercase text-sm bg-mate-ink dark:bg-white text-white dark:text-mate-ink border-2 border-mate-ink dark:border-white rounded shadow-block dark:shadow-block-dark hover:shadow-block-hover dark:hover:shadow-block-dark-hover hover:-translate-y-0.5 transition-all"
                    >
                        Confirm
                    </button>
                </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;