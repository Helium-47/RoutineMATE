import { GoogleGenAI, Type } from "@google/genai";
import { Task } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getGeminiRoast = async (tasks: Task[], viewMode: string): Promise<{ text: string, mood: string }> => {
  try {
    const activeTasks = tasks.filter(t => t.type === viewMode);
    const completed = activeTasks.filter(t => t.completed).length;
    const total = activeTasks.length;

    const prompt = `
      The user is looking at their "${viewMode}" list.
      Stats: ${completed} completed out of ${total}.
      Tasks: ${JSON.stringify(activeTasks.map(t => ({ text: t.text, completed: t.completed })))}.
      
      Act as a high-energy "Gen Z Productivity Hype Man" or a "Stoic Gym Bro".
      Use slang like "lock in", "no cap", "main character energy", "W", "L", "cooking", "grindset".
      
      If they have 0 tasks done: Motivate them to start. Tell them to lock in.
      If they are halfway: Tell them to keep cooking.
      If they are done: Hype them up! Massive W.
      
      Keep it short (max 2 sentences).
      
      Also pick a hex color code for the message background (e.g. #ef4444 for warning, #22c55e for success, #3b82f6 for neutral).
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            text: { type: Type.STRING },
            mood: { type: Type.STRING, description: "Hex color code" },
          },
          required: ["text", "mood"]
        }
      }
    });

    const result = JSON.parse(response.text || "{}");
    return {
      text: result.text || "Time to lock in, bro.",
      mood: result.mood || "#cbd5e1"
    };

  } catch (error) {
    console.error("Gemini Coach Error:", error);
    return {
      text: "Wifi down but the grind never stops.",
      mood: "#94a3b8"
    };
  }
};
